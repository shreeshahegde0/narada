import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { TweetService } from '../../core/services/tweet.service';
import { TweetCardComponent } from '../../shared/components/tweet-card/tweet-card.component';
import { Observable, switchMap, tap, of } from 'rxjs';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, TweetCardComponent, RouterModule],
  templateUrl: './profile.component.html'
})
export class ProfileComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private tweetService = inject(TweetService);

  user$: Observable<any> | null = null;
  userTweets$: Observable<any[]> | null = null;
  isLoading = true;

  ngOnInit() {
    // We use paramMap so if you click a mention while ALREADY on a profile page, it updates
    this.user$ = this.route.paramMap.pipe(
      tap(() => this.isLoading = true),
      switchMap(params => {
        const username = params.get('username');
        if (!username) return of(null);
        
        // Kick off the tweet fetch simultaneously
        this.userTweets$ = this.tweetService.getTweetsByUsername(username);
        
        return this.tweetService.getUserByUsername(username).pipe(
          tap(() => this.isLoading = false)
        );
      })
    );
  }
}