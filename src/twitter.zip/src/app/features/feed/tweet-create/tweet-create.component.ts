import { Component, inject, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TweetService } from '../../../core/services/tweet.service';
import { AuthService } from '../../../core/services/auth.service';
import { Subject, debounceTime, distinctUntilChanged, switchMap, of, Subscription } from 'rxjs';

@Component({
  selector: 'app-tweet-create',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './tweet-create.component.html'
})
export class TweetCreateComponent implements OnDestroy {
  @ViewChild('tweetInput') tweetInput!: ElementRef<HTMLTextAreaElement>;
  
  authService = inject(AuthService);
  private tweetService = inject(TweetService);
  
  content = '';
  
  // Suggestion Engine State
  showSuggestions = false;
  suggestionType: 'users' | 'hashtags' | null = null;
  suggestions: any[] = [];
  
  private searchSubject = new Subject<{ type: 'users' | 'hashtags', query: string }>();
  private searchSub: Subscription;

  constructor() {
    this.searchSub = this.searchSubject.pipe(
      debounceTime(200),
      distinctUntilChanged((prev, curr) => prev.query === curr.query),
      switchMap(({ type, query }) => {
        if (type === 'users') return this.tweetService.searchUsers(query);
        if (type === 'hashtags') return this.tweetService.searchHashtags(query);
        return of([]);
      })
    ).subscribe(results => {
      this.suggestions = results;
      this.showSuggestions = results.length > 0;
    });
  }

  // Detects what word the cursor is currently on
  onInput(event: Event) {
    const input = event.target as HTMLTextAreaElement;
    const textUpToCursor = this.content.substring(0, input.selectionStart);
    const words = textUpToCursor.split(/\s+/);
    const currentWord = words[words.length - 1];

    if (currentWord.startsWith('@') && currentWord.length > 1) {
      this.suggestionType = 'users';
      this.searchSubject.next({ type: 'users', query: currentWord });
    } else if (currentWord.startsWith('#') && currentWord.length > 1) {
      this.suggestionType = 'hashtags';
      this.searchSubject.next({ type: 'hashtags', query: currentWord });
    } else {
      this.closeSuggestions();
    }
  }

  // Replaces the partial word with the full suggestion
  selectSuggestion(suggestion: any) {
    const input = this.tweetInput.nativeElement;
    const cursorPosition = input.selectionStart;
    
    const textUpToCursor = this.content.substring(0, cursorPosition);
    const textAfterCursor = this.content.substring(cursorPosition);
    
    const words = textUpToCursor.split(/\s+/);
    words.pop(); // Remove the partial '@al' or '#ang'
    
    const replacement = this.suggestionType === 'users' ? `@${suggestion.username}` : suggestion;
    
    // Stitch it back together
    const newTextUpToCursor = words.length > 0 ? words.join(' ') + ' ' + replacement + ' ' : replacement + ' ';
    this.content = newTextUpToCursor + textAfterCursor;
    
    this.closeSuggestions();
    
    // Refocus the textarea and push the cursor to the end of the newly inserted word
    setTimeout(() => {
      input.focus();
      input.setSelectionRange(newTextUpToCursor.length, newTextUpToCursor.length);
    }, 0);
  }

  closeSuggestions() {
    this.showSuggestions = false;
    this.suggestions = [];
    this.suggestionType = null;
  }

  onSubmit() {
    if (!this.content.trim()) return;
    
    const newTweet = {
      content: this.content,
      userId: this.authService.currentUser?.id,
      username: this.authService.currentUser?.username,
      firstName: this.authService.currentUser?.firstName,
      profilePictureUrl: this.authService.currentUser?.profilePictureUrl,
      createdAt: new Date().toISOString(),
      likes: 0,
      retweets: 0,
      replies: 0
    };

    this.tweetService.createTweet(newTweet).subscribe(() => {
      this.content = '';
      this.closeSuggestions();
    });
  }

  ngOnDestroy() {
    this.searchSub?.unsubscribe();
  }
}