import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap, map, of } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TweetService {
  private http = inject(HttpClient);
  private apiUrl = environment.apiUrl;

  private tweetsSubject = new BehaviorSubject<any[]>([]);
  tweets$ = this.tweetsSubject.asObservable();

  refreshTweets(): void {
    this.http.get<any[]>(`${this.apiUrl}/tweets?_sort=createdAt&_order=desc`).subscribe(data => {
      this.tweetsSubject.next(data);
    });
  }

  createTweet(tweet: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/tweets`, tweet).pipe(
      tap(() => this.refreshTweets())
    );
  }

  // FIXED: Restoring the missing delete method
  deleteTweet(id: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/tweets/${id}`).pipe(
      tap(() => this.refreshTweets())
    );
  }


  // Fetch a single user by their exact username
  getUserByUsername(username: string): Observable<any> {
    // json-server returns an array when querying, so we map to the first result
    return this.http.get<any[]>(`${this.apiUrl}/users?username=${username}`).pipe(
      map(users => users[0] || null)
    );
  }

  // Fetch only the tweets belonging to this user
  getTweetsByUsername(username: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/tweets?username=${username}&_sort=createdAt&_order=desc`);
  }


  /**
   * High-Precision Search
   * Ensures #f only matches #f and NOT #frontend
   */
searchTweets(query: string): Observable<any[]> {
    const term = query.trim();
    if (!term) return of([]);

    return this.http.get<any[]>(`${this.apiUrl}/tweets`).pipe(
      map(tweets => tweets.filter(t => {
        const content = (t.content || '').toLowerCase();
        const search = term.toLowerCase();

        // Check if the user just finished a word (ends with a space)
        const isFinalWord = query.endsWith(' ');

        if (isFinalWord) {
          // STRICT MODE: Only match if the tag is a standalone word
          // This ensures "#f " does NOT match "#frontend"
          const escapedSearch = search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          const strictRegex = new RegExp(`(?:^|\\s)${escapedSearch}(?:\\s|$)`, 'i');
          return strictRegex.test(content);
        } else {
          // TYPING MODE: Match if the content starts with this prefix
          // This ensures "#f" DOES match "#frontend" while you are still typing
          return content.includes(search);
        }
      })),
      map(tweets => tweets.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()))
    );
  }

  // Extracts unique hashtags from existing tweets for autocomplete suggestions
// SEARCH USERS (Now with Duplicate Prevention)
  // SEARCH USERS (Strict Deduplication)
  searchUsers(query: string): Observable<any[]> {
    const term = query.toLowerCase().replace('@', '').trim();
    if (!term) return of([]);
    
    return this.http.get<any[]>(`${this.apiUrl}/users`).pipe(
      map(users => {
        const uniqueUsers = new Map<string, any>();
        
        users.forEach(u => {
          const username = (u.username || '').toLowerCase();
          const firstName = (u.firstName || '').toLowerCase();
          
          // If it matches the search term and we haven't added this username yet
          if ((username.includes(term) || firstName.includes(term)) && !uniqueUsers.has(username)) {
            uniqueUsers.set(username, u);
          }
        });

        return Array.from(uniqueUsers.values());
      })
    );
  }

  // SEARCH HASHTAGS (Regex Extraction + Deduplication)
  searchHashtags(query: string): Observable<string[]> {
    const term = query.toLowerCase().trim();
    if (!term) return of([]);

    return this.http.get<any[]>(`${this.apiUrl}/tweets`).pipe(
      map(tweets => {
        const uniqueTags = new Map<string, string>();
        
        tweets.forEach(t => {
          // STRICT REGEX: Grabs the '#' followed by letters, numbers, or underscores.
          // This automatically strips off periods, commas, or exclamation points!
          const matches = (t.content || '').match(/#[a-zA-Z0-9_]+/g);
          
          if (matches) {
            matches.forEach((tag: string) => {
              const lowerTag = tag.toLowerCase();
              if (!uniqueTags.has(lowerTag)) {
                uniqueTags.set(lowerTag, tag);
              }
            });
          }
        });
        
        // Return filtered array
        return Array.from(uniqueTags.values())
          .filter(tag => tag.toLowerCase().includes(term));
      })
    );
  }

}



